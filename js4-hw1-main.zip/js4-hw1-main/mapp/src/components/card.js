function Card() {
    return <div classnName="card">
        <div class="container">
            <img src="https://naked-science.ru/wp-content/uploads/2018/09/field_image_383831793.jpg"></img>
            <b>Цена: 500$</b>
            <p>Порода собаки: Карликовый пинчер</p>
        </div>

    </div>
}

export default Card